export default function Register() {
  return <h1>Página de cadastro</h1>;
}
