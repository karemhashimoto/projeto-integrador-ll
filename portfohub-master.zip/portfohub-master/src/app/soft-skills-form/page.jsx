export default function SoftSkillsForm() {
  return <h1>Formulário de habilidades pessoais</h1>;
}
