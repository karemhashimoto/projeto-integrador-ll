export default function Login() {
  return <h1>Página de login</h1>;
}
