export default function AcademicBgform() {
  return <h1>Formulário de formação academica</h1>;
}
