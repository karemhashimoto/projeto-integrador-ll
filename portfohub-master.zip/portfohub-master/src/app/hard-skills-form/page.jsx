export default function HardSkillsForm() {
  return <h1>Formulário de habilidades técnicas</h1>;
}
