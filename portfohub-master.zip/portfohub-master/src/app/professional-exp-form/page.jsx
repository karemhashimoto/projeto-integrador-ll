export default function ProfessionalExpForm() {
  return <h1>Formulário experiência profissional</h1>;
}
