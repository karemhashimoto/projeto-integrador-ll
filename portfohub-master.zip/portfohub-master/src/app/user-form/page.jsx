export default function UserForm() {
  return <h1>Formulário de dados pessoais</h1>;
}
