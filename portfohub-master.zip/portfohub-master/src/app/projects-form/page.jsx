export default function ProfessionalExpForm() {
  return <h1>Formulário de projetos</h1>;
}
